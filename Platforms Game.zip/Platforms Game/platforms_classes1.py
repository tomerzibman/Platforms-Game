#################################
# Programer: Tomer Zibman
# Date: December 26, 2016
# Description: Platforms
################################
import pygame

GRIDSIZE = 10
HEIGHT = 600
WIDTH  = 800

rectB = pygame.image.load('rectB.bmp')
rectB = pygame.transform.scale(rectB, (GRIDSIZE, GRIDSIZE))

rectO = pygame.image.load('rectO.bmp')
rectO = pygame.transform.scale(rectO, (GRIDSIZE, GRIDSIZE))

platform = pygame.image.load('platform.bmp')
platform = pygame.transform.scale(platform, (GRIDSIZE, GRIDSIZE))

drop = pygame.image.load('drop.bmp')
drop = pygame.transform.scale(drop, (GRIDSIZE*2, GRIDSIZE*2))

coin_pics=[]
for i in range(1,7):
    coin=pygame.image.load('coin_rot_'+str(i)+'.bmp')
    coin=pygame.transform.scale(coin,(GRIDSIZE*2, GRIDSIZE*2))
    coin_pics.append(coin)

angle = [0, 10, 20, 30, 40, 50, 60, 60, 70, 80, 100, 110, 120, 130, 140, 150, 160, 170]

class Block(object):
    """ A square - basic building block
        data:               behaviour:
            col - column        move down
            row - row           draw
            clr - colour
            angle - rotation angle
    """
    def __init__(self, col = 1, row = 1, clr = 1, ang = 0):
        self.col = col
        self.row = row
        self.clr = clr
        self.angle = ang

    def __str__(self):
        return '('+str(self.col)+','+str(self.row)+') '+ CLR_names[self.clr]

    #draws the objects
    def draw(self, surface, gridsize=20, blockID=0, rotation = 0 , imgnum=0):
        x = self.col * gridsize
        y = self.row * gridsize
        self.angle = angle[rotation]
        if blockID == 0:
            rect_B=pygame.transform.rotate(rectB,self.angle)
            surface.blit(rect_B, (x,y))
        elif blockID == 1:
            rect_O=pygame.transform.rotate(rectO,self.angle)
            surface.blit(rect_O, (x,y))
        elif blockID == 2:
            surface.blit(platform, (x, y))
        elif blockID == 3:
            surface.blit(coin_pics[imgnum], (x, y))
        else:
            surface.blit(drop, (x, y))

    # Moves objects down
    def move_down(self):
        self.row = self.row + 1


#-------------------------------#
class Cluster(object):
    """ Collection of blocks
        data:
            col - column where the anchor block is located
            row - row where the anchor block is located
            blocksNo - number of blocks
    """
    def __init__(self, col = 1, row = 1, blocksNo = 1):
        self.col = col
        self.row = row
        self.clr = 0
        self.blocks = [Block()]*blocksNo
        self._colOffsets = [0]*blocksNo
        self._rowOffsets = [0]*blocksNo

    def _update(self):
        for i in range(len(self.blocks)):
            blockCOL = self.col+self._colOffsets[i]
            blockROW = self.row+self._rowOffsets[i]
            blockCLR = self.clr
            self.blocks[i]= Block(blockCOL, blockROW, blockCLR, 0)

    def draw(self, surface, gridsize, blockid=0,rot=0,img_num=0):
        for block in self.blocks:
            block.draw(surface, gridsize,blockid,rot,img_num)

    # Method that checks for collisoins
    def collides(self, other):                          
        for block in self.blocks:
            for obstacle in other.blocks:
                if block.col == obstacle.col and block.row == obstacle.row:
                    return True
        return False

    # Method that adds appends objects
    def append(self, other):
        for block in other.blocks:
            self.blocks.append(Block(block.col,block.row,block.clr,block.angle))

#---------------------------------------#
class Platform(Cluster):
    """ Horizontal line of blocks
        data:
            col - column where the anchor block is located
            row - row where the anchor block is located
            blocksNo - number of blocks
            move - tells if platform is moving or not
            direction - platform current moving direction (0-left, 1-right)
    """
    def __init__(self, col = 0, row = 0, blocksNo = 0, move=False, direction = 0):
        Cluster.__init__(self, col, row, blocksNo*2)
        self.move = move
        self.direction = direction
        for i in range(blocksNo):
            self._colOffsets[i] = i
            self._rowOffsets[i] = 0
        for i in range(blocksNo):
            self._colOffsets[blocksNo+i] = i
            self._rowOffsets[blocksNo+i] = 1
        self._update() # private

    # Method that checks if object is moving
    def isMoving(self):
        return self.move

    # Method that returns the direction of an object
    def getDirection(self):
        return self.direction

    # Method that moves the object left
    def move_left(self,leftWall):
        self.col = self.col - 1
        self._update()
        if(self.collides(leftWall)):
            self.direction=1

    def move_right(self,rightWall):
        self.col = self.col + 1
        self._update()
        if(self.collides(rightWall)):
            self.direction=0

    def get_row(self):
        return self.row

    def get_col(self):
        return self.col

#---------------------------------------#
class Player(Cluster):
    """ Collection of blocks creating a player object.

    """
    def __init__(self, col = 0, row = 0, blocksNo = 1):
        Cluster.__init__(self, col, row, 4)
        self._colOffsets = [0, 1, 0, 1]
        self._rowOffsets = [0, 0, 1, 1]
        self.touchingPlatform = True
        self.doubJump = False
        self._update() # private

    def move_right(self,otherPlayer,coin,otherP):           # Method to move the object one column right
        self.col = self.col + 1
        if(self.col > 79):
            self.col = 0
        self._update() # private
        for pl in otherP:   #check if player colliding with any platform
            if(self.collides(pl)==True):
                while(self.collides(pl)==True):
                    self.row = self.row + 1
                    self._update() # private
                break
        if(self.collides(otherPlayer)==True): #check if player colliding with other player
            self.move_left(otherPlayer,coin,otherP)
        if(self.collides(coin)==True):  #check if player colliding with coin
            return True
        else:
            return False

    def move_left(self,otherPlayer,coin,otherP):            # Method to move the object one column left
        self.col = self.col - 1
        if(self.col < 0):
            self.col = 79
        self._update() # private
        for pl in otherP:
            if(self.collides(pl)==True): #check if player colliding with any platform
                while(self.collides(pl)==True):
                    self.row = self.row + 1
                    self._update() # private
                break
        if(self.collides(otherPlayer)==True): #check if player colliding with other player
            self.move_right(otherPlayer,coin,otherP)
        if(self.collides(coin)==True): #check if player colliding with coin
            return True
        else:
            return False

    # a method to move player smoothly up or down, it also check if while moving it collides with any other object (platform, other player or coin)
    # the method returns two variables:
    # speed -> current player speed
    # touchingCoin -> if player touching a coin yes or no
    def move_vertically(self,sf,speed,anyPlatform,otherPlayer,coin):
        self.touchingPlatform = False
        if(speed >= 0): #moving down
            step=1
        else:           #moving up
            step = -1
            speed = -speed
        #move player row by row, update screen and check for any collisions
        for v in range(speed+1):
            coin_collision = False
            otherPlayer_collision = False
            platform_collision = False
            self.row = self.row + step  # move player in up or down one row
            self._update()
            self.draw(sf,GRIDSIZE)
            pygame.time.delay(3)
            if(self.collides(otherPlayer) == True): # check if player colliding with the other player
                otherPlayer_collision = True
                self.touchingPlatform = True
            for plat in anyPlatform:    #check if player colliding with any of the platforms
                if(self.collides(plat) == True):
                    platform_collision=True
                    if(step == 1):
                        self.touchingPlatform = True
                    if(step==1 and plat.isMoving() == True):
                        if(plat.getDirection() == 0):
                           self.col=self.col-1 #platform moving to the left
                        else:
                           self.col=self.col+1 #platform moving to the righT
                    self._update()
                    break
            if(self.collides(coin) == True):    # check if player colliding with a coin
                coin_collision = True
            if(coin_collision == True or otherPlayer_collision == True or platform_collision == True):
                self.row = self.row - step #since there is a collision move 1 row in the opposite direction
                self._update()
                if(platform_collision==True):   # check for possible colission again
                    if(self.collides(plat)==True):
                        self.row = self.row - step
                        self._update()
                self.draw(sf,GRIDSIZE)
                speed = 0
                if(step == 1):
                    self.reset_double()
                break
        return (step*speed),coin_collision

    def get_row(self):
        return self.row

    def is_air(self):
        return not(self.touchingPlatform)

    def is_double(self):
        return self.doubJump

    def set_double(self):
        self.doubJump = True

    def reset_double(self):
        self.doubJump = False

class Wall(Cluster):
    """ Vertical line of blocks
        data:
            col - column where the anchor block is located
            row - row where the anchor block is located
            blocksNo - number of blocks
    """
    def __init__(self, col = 1, row = 1, blocksNo = 1):
        Cluster.__init__(self, col, row, blocksNo)
        for i in range(blocksNo):
            self._rowOffsets[i] = i
        self._update() # private Make sure all the methods marked as private have an underscore before its name

#---------------------------------------#
class Coin(Cluster):
    """ coin is basically a cluster and have only single block

    """
    def __init__(self, col = 0, row = 0, blocksNo = 1):
        Cluster.__init__(self, col, row, 1)
        for i in range(blocksNo):
            self._colOffsets[i] = i
        self._update() # private

#---------------------------------------#
class Obstacle(Cluster):
    """ obstacle is basically a cluster and have only single block

    """
    def __init__(self, col = 0, row = 0, blocksNo = 1):
        Cluster.__init__(self, col, row, 1)
        for i in range(blocksNo):
            self._colOffsets[i] = i
        self._update() # private
    def move_down(self):              # Method to move the object up
        self.row = self.row + 1
        self._update() # private
    def get_row(self):
        return self.row
