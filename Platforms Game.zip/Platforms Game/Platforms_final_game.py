#################################
# Programer: Tomer Zibman
# Date: December 25, 2016
# Description: Platforms

################################
from platforms_classes1 import *
import pygame
from random import randint
import math
import time

pygame.init()
#----------------#
# Game Constants #
#----------------#
HEIGHT = 600
WIDTH  = 800
GRIDSIZE = 10
GROUND = HEIGHT
GRAVITY = 1
JUMP = 4
WINNING_SCORE = 5
DROP_CHANCE = 10 # percent
MAX_DROPS = 10
#----------------#
# Color Cobtants #
#----------------#
WHITE = (255, 255, 255)
BLACK = (  0,   0,   0)
BLUE = (0 , 0, 255)
ORANGE = (255, 160, 0)
#----------------#
# Game Variables #
#----------------#
player1_rot=0
player2_rot=0
frame_count=0
inPlay = True
player1_vy=0
player2_vy=0
player1_score = 0
player2_score = 0
pauseEnable = False
round_counter = 1
restart_round = False
player1_touching_coin = False
player2_touching_coin = False
game_pause = False
drop_show = False
drops_cnt = 0
#-----------------#
# Sound Variables #
#-----------------#
pygame.mixer.init()
sound_game_done = pygame.mixer.Sound("game_done.wav")
sound_jump = pygame.mixer.Sound("jump.wav")

screen=pygame.display.set_mode((WIDTH, HEIGHT))

bg = pygame.image.load('sky.bmp')
bg = pygame.transform.scale(bg, (WIDTH, HEIGHT))

instructionsI = pygame.image.load('instructionsButton.bmp')
instructionsI = pygame.transform.scale(instructionsI, (300, 100))

backArrowI = pygame.image.load('backButton.bmp')
backArrowI = pygame.transform.scale(backArrowI, (200, 100))

faded_rect = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA, 32)
faded_rect.fill((15, 15, 15, 100))
#----------------------------#
# create font & text objects #
#----------------------------#
myFont = pygame.font.SysFont('Arial',32, True)
myFont2 = pygame.font.SysFont('Arial', 48, True)
myFont3 = pygame.font.SysFont('Arial', 20, True)
keyText = myFont3.render('Press the space bar to play!', 1, BLUE)
pauseText = myFont3.render('Press p to pause', 1, BLACK)
resumeText = myFont3.render('Press p to resume', 1, WHITE)
gameOverText = myFont.render('G A M E  O V E R', 1, WHITE)
quitText = myFont3.render("Press the 'escape' key to quit", 1, WHITE)
winP1Text = myFont.render("Player One Wins!", 1, BLUE)
winP2Text = myFont.render("Player Two Wins!", 1, ORANGE)
platformText = myFont2.render("P L A T F O R M S  G A M E", 1, WHITE)
creatorText = myFont3.render("By: Tomer Zibman", 1, WHITE)
p1scoreText = myFont3.render(str(player1_score), 1, BLUE)
p2scoreText = myFont3.render(str(player2_score), 1, ORANGE)
instructionsText = myFont2.render('I N S T R U C T I O N S', 1, WHITE)
howToPlayText = myFont.render("How to play:", 1, WHITE)
p1InstructionsText = myFont.render('Player 1: Use the arrow keys to move', 1, ORANGE)
p2InstructionsText = myFont.render('Player 2: Use W A D to move', 1, BLUE)
winText = myFont3.render('To win the game you must collect 5 coins before your opponent does', 1, BLACK)
pasuedText = myFont2.render('P A U S E D!', 1, WHITE)
dropText = myFont3.render("Avoid getting hit by the rain drops or else your opponent will gain a point", 1, BLACK)
#-------------------------#
# Define screen platforms #
#-------------------------#
platform_col=[2,10,10,2,66,56,56,66,32,32]
platform_row=[10,20,40,50,10,20,40,50,58,30]
platform_len=[12]*10
platform_move=[False,False,False,False,False,False,False,False,True,True]
platform_direction=[0,0,0,0,0,0,0,0,0,1]
plat=[Platform()]*len(platform_len)
#----------------------------------------------#
# Game start Function: displays opening screen #
#----------------------------------------------#
def instructions():
    runLoop = True
    while(runLoop):
        screen.fill(BLACK)
        screen.blit(bg, (0,0))
        screen.blit(instructionsText, (150, 100))
        screen.blit(howToPlayText, (300, 200))
        screen.blit(p1InstructionsText, (100, 300))
        screen.blit(p2InstructionsText, (100, 350))
        screen.blit(winText, (100, 425))
        screen.blit(dropText, (100, 450))
        screen.blit(backArrowI, (50, 500))
        pygame.display.update()
        events = pygame.event.get()
        for event in events:
            if (event.type == pygame.MOUSEBUTTONDOWN):
                (cursorX, cursorY) = pygame.mouse.get_pos()
                if ((cursorX>=50 and cursorX<=250) and (cursorY>=500 and cursorY<=600)):
                    runLoop = False

def start(cnt):
    screen.fill(BLACK)
    platformText = myFont2.render("P L A T F O R M S  G A M E", 1, (randint(0,255),randint(0,255),randint(0,255)))
    screen.blit(bg, (0,0))
    screen.blit(platformText, (115, 275))
    screen.blit(creatorText, (325, 350))
    screen.blit(instructionsI, (500, 500))
    if(cnt%2==0):
        screen.blit(keyText, (275, 425))
    pygame.display.update()
#---------------------#
# Start Page Function #
#---------------------#
def startPage():
    run_loop = True
    cnt=0
    while (run_loop):
        start(cnt)
        cnt+=1
        events = pygame.event.get()
        for event in events:
            if (event.type == pygame.KEYDOWN):
                if event.key == pygame.K_SPACE:
                    run_loop = False
            if (event.type == pygame.MOUSEBUTTONDOWN):
                (cursorX, cursorY) = pygame.mouse.get_pos()
                if ((cursorX>=500 and cursorX<=800) and (cursorY>=500 and cursorY<=600)):
                    instructions()
                else:
                    start(cnt)
        pygame.time.delay(350)
#-----------------------------------------------#
# Game Over Function: displays game over screen #
#-----------------------------------------------#
def gameOverPage(p1score, p2score):
    run_loop = True
    cnt=0
    sound_game_done.play()
    while(run_loop):
        screen.fill(BLACK)
        screen.blit(gameOverText, (280, 200))
        screen.blit(quitText, (275, 250))
        if(cnt%2 == 0):
            if (p1score == WINNING_SCORE):
                screen.blit(winP1Text, (300, 300))
            else:
                screen.blit(winP2Text, (300, 300))
        cnt += 1
        pygame.display.update()
        events = pygame.event.get()
        for event in events:
            if(event.type == pygame.KEYDOWN):
                if(event.key == pygame.K_ESCAPE):
                    run_loop = False
        pygame.time.delay(350)
#----------------------------------------------------#
# redraw screen Function: main game drawing function #
#----------------------------------------------------#
def redraw_screen(fcnt,gpause):
    screen.fill(BLACK)
    screen.blit(bg, (0, 0))
    player1.draw(screen,GRIDSIZE,0,0)
    player2.draw(screen,GRIDSIZE,1,0)
    if(gpause==False):
        myCoin.draw(screen,GRIDSIZE,3,0,(fcnt%6))
    else:
        myCoin.draw(screen,GRIDSIZE,3,0,0)
    for drop in myDrops:
        drop.draw(screen,GRIDSIZE,4,0)
    for platform in myPlatforms:
        platform.draw(screen,GRIDSIZE,2)
    p1scoreText = myFont3.render(str(player1_score), 1, BLUE)
    screen.blit(p1scoreText, (40, 30))
    p2scoreText = myFont3.render(str(player2_score), 1, ORANGE)
    screen.blit(p2scoreText, (750, 30))
    if(gpause==False):
        screen.blit(pauseText, (300, 20))
    else:
        screen.blit(faded_rect, (0, 0))
        screen.blit(resumeText, (315, 325))
        screen.blit(pasuedText, (265, 250))
    pygame.display.update()
#----------------------------------------------------#
# start round Function: counts down before new round #
#----------------------------------------------------#
def start_round(round_num):
    countdown=4
    while(countdown>0):
        screen.fill(BLACK)
        roundText = myFont2.render("ROUND #"+str(round_num), 1, WHITE)
        screen.blit(roundText, (275, 200))
        if(countdown==4):
            getReadyText = myFont2.render("GET READY", 1, WHITE)
            screen.blit(getReadyText, (250, 300))
        else:
            numberText = myFont2.render(str(countdown), 1, WHITE)
            screen.blit(numberText, (375, 300))
        pygame.display.update()
        pygame.time.delay(1000)
        countdown=countdown-1


#---------------------#
#    Main Program     #
#---------------------#
startPage()
#---------------------#
# create game objects #
#---------------------#
player1=Player(4,48,1)
player2=Player(74,48,1)
leftWall = Wall(-1, 0, HEIGHT//GRIDSIZE)
rightWall = Wall(80, 0, HEIGHT//GRIDSIZE)
myDrops=[]
myPlatforms=[]
for i in range(len(platform_len)):
    myPlatforms.append(Platform(platform_col[i],platform_row[i],platform_len[i],platform_move[i],platform_direction[i]))
myCoin=Coin(40,randint(1,35),1)

start_round(round_counter)
#-----------#
# Main Loop #
#-----------#
while (inPlay == True):

    if(restart_round==True): # here we reset game variables when starting a new round
        restart_round=False
        drop_show = False
        drops_cnt = 0
        myDrops = []
        player1=Player(4,48,1)
        player2=Player(74,48,1)
        while (True):   #create a new coin at a random location
            myCoin=Coin(randint(0,78),randint(0,35),1)
            for plat in myPlatforms:    # make sure the coin is not colliding with any of the platforms
                if(myCoin.collides(plat)==True):
                    break
            break

    events = pygame.event.get()
    for event in events:
        if event.type == pygame.QUIT:
            inPlay = False

    keys = pygame.key.get_pressed()
    if(frame_count%3 == 0):
        if keys[pygame.K_p]:
            if(game_pause == False):
                game_pause = True
            else:
                game_pause = False

    if(game_pause == False):
        # player 1 keys
        if keys[pygame.K_a]:
            player1_touching_coin=player1.move_left(player2,myCoin,myPlatforms)
        if keys[pygame.K_d]:
            player1_touching_coin=player1.move_right(player2,myCoin,myPlatforms)
        if keys[pygame.K_w]:
            if(player1.is_air() == False): # handle jump player 1
                player1_vy=-JUMP
            else:
                if(player1_vy>=2 and player1.is_double()==False): # handle double jump player 1
                    player1.set_double()
                    player1_vy=-JUMP
        # player 2 keys
        if keys[pygame.K_LEFT]:
            player2_touching_coin=player2.move_left(player1,myCoin,myPlatforms)
        if keys[pygame.K_RIGHT]:
            player2_touching_coin=player2.move_right(player1,myCoin,myPlatforms)
        if keys[pygame.K_UP]:
            if(player2.is_air() == False): # handle jump player 2
                player2_vy=-JUMP
            else:
                if(player2_vy>=2 and player2.is_double()==False): # handle double jump player 2
                    player2.set_double()
                    player2_vy=-JUMP

        if(player1_touching_coin==True): # handle case when player 1 touching coin
            player1_touching_coin=False
            myCoin=Coin(0,0,0)
            player1_score = player1_score + 1
            round_counter += 1
            if(player1_score<WINNING_SCORE):
                start_round(round_counter)
                restart_round=True

        if(player2_touching_coin==True): # handle case when player 1 touching coin
            player2_touching_coin=False
            myCoin=Coin(0,0,0)
            player2_score = player2_score + 1
            round_counter += 1
            if(player2_score<WINNING_SCORE):
                start_round(round_counter)
                restart_round=True
        # move player 1 & player 2 vertically (up or down) and check for collisions
        player1_vy,player1_touching_coin=player1.move_vertically(screen,player1_vy,myPlatforms,player2,myCoin)
        player2_vy,player2_touching_coin=player2.move_vertically(screen,player2_vy,myPlatforms,player1,myCoin)
        # update gravity for both players
        player1_vy=player1_vy+GRAVITY
        player2_vy=player2_vy+GRAVITY
        # randomly create new obstacle (drop)
        if(drops_cnt < MAX_DROPS):
            if(randint(1,100) < DROP_CHANCE):
                drops_cnt += 1
                drop=Obstacle(randint(0,WIDTH/GRIDSIZE-1),0,1)
                myDrops.append(drop)
                drop_show = True
        # handle obstacles (drops)
        if(drop_show == True):
            for d in myDrops:
                d.move_down() # move drop down (no gravity)
                if(d.collides(player1) == True): # handle case when drop is touching player 1
                    player2_score += 1
                    round_counter += 1
                    if(player2_score<WINNING_SCORE):
                        start_round(round_counter)
                        restart_round=True
                if(d.collides(player2) == True): # handle case when drop is touching player 1
                    player1_score += 1
                    round_counter += 1
                    if(player1_score<WINNING_SCORE):
                        start_round(round_counter)
                        restart_round=True
                if(d.get_row() > HEIGHT/GRIDSIZE): # remove drop when reaches bottom of screen
                    myDrops.remove(d)
                    drops_cnt -= 1
                    if(drops_cnt == 0):
                        drop_show = False

        if(player1_touching_coin==True): # handle case when player 1 touching coin
            player1_touching_coin=False
            myCoin=Coin(0,0,0)
            player1_score = player1_score + 1
            round_counter += 1
            if(player1_score<WINNING_SCORE):
                start_round(round_counter)
                restart_round=True

        if(player2_touching_coin==True): # handle case when player 2 touching coin
            player2_touching_coin=False
            myCoin=Coin(0,0,0)
            player2_score = player2_score + 1
            round_counter += 1
            if(player2_score<WINNING_SCORE):
                start_round(round_counter)
                restart_round=True

        for plat in myPlatforms:    # handle moving platforms
            if(plat.isMoving() == True):
                if(plat.getDirection() == 0):
                    plat.move_left(leftWall)
                else:
                    plat.move_right(rightWall)

        if(player1.get_row() > HEIGHT/GRIDSIZE): # handle case when player 1 is falling off screen
            player2_score = player2_score + 1
            round_counter += 1
            if(player2_score<WINNING_SCORE):
                start_round(round_counter)
                restart_round=True

        if(player2.get_row() > HEIGHT/GRIDSIZE): # handle case when player 2 is falling off screen
            player1_score = player1_score + 1
            round_counter += 1
            if(player1_score<WINNING_SCORE):
                start_round(round_counter)
                restart_round=True

    frame_count=frame_count+1
    if(player1_score==WINNING_SCORE or player2_score==WINNING_SCORE): # check if any player is winner
        gameOverPage(player1_score, player2_score)
        inPlay = False
    else:   # if no winner, redraw screen and start main loop again
        #if(game_pause == False):
        redraw_screen(frame_count,game_pause)
    # frame delay in milli seconds
    pygame.time.delay(40)
#-----------#
# quit game #
#-----------#
pygame.quit()

