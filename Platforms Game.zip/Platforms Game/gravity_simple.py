#########################################
# Programmer: Mz. G
# Date: 07/01/2016
# File Name: gravity.py
# Description: Demonstrates how to use platforms to support an object under gravity
#########################################
import pygame
import random
pygame.init()

HEIGHT = 600
WIDTH  = 800
screen=pygame.display.set_mode((WIDTH,HEIGHT))

BLACK = (  0,  0,  0)
WHITE = (255,255,255)
RED   = (255,  0,  0)

OUTLINE=0
GROUND = HEIGHT
GRAVITY = 2
HORI_SPEED = 15
VERT_SPEED = -40

#---------------------------------------#
# function that redraws all objects     #
#---------------------------------------#
def redraw_screen():
    screen.fill(BLACK)
    pygame.draw.rect(screen,RED,(boxX,boxY,boxWidth,boxHeight),OUTLINE)
    pygame.display.update()
    
#---------------------------------------#
# main program starts here              #
#---------------------------------------#    
boxWidth = 20       
boxHeight = 20
boxX = WIDTH//6     #make these lists with different coordinates like pop the baloons game
boxY = GROUND - boxHeight
boxVx = HORI_SPEED
boxVy = VERT_SPEED

#---------------------------------------# 

inPlay = True

while inPlay:               
           
                                     
    pygame.event.get()
    keys = pygame.key.get_pressed()
    if keys[pygame.K_ESCAPE]:
        inPlay = False
        
    boxX = boxX + boxVx
    boxVy = boxVy + GRAVITY
    boxY = boxY + boxVy
    #print ("x= ",boxX, "  y= ",boxY, "Vx= ",boxVx, "  Vy= ",boxVy) # for troubleshooting


    if boxY<-10 or boxY>600: # if the square goes out of the screen then restart
        boxX = random.randint (-200,1000)
        boxVx= random.randint (10,30)
        if boxX>400:
            boxVx*=-1
        boxY = GROUND - boxHeight
        boxVy = random.randint (-50,-30)
        print (boxX, "  ", boxY, "Start again") # for troubleshooting
        
    redraw_screen()
    pygame.time.delay(30)
    
#---------------------------------------# 
pygame.quit()




  
